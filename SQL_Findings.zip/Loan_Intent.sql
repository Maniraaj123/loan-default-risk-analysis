SELECT
    loan_intent,
    SUM(CASE WHEN loan_status = 1 THEN 1 ELSE 0 END) AS Bankrupt,
    SUM(CASE WHEN loan_status = 0 THEN 1 ELSE 0 END) AS [Still in],
    -- This calculates the decimal, then chops it off into a whole number
    CAST(SUM(CASE WHEN loan_status = 1 THEN 1.0 ELSE 0.0 END) / COUNT(*) * 100 AS Decimal) AS Bankrupt_Pct
FROM
    SQL_Data
GROUP BY
    loan_intent;

-- An individual's purpose for borrowing has a heavy influence over here as the bankruptcy percentage is significanlty different. 
-- It's strange but those who take on significantly risky project actually seem to repay their loan. Additionally, educational loan is another one to consider,
-- student's are more likely to repay their loan.
-- Finally, lenders should do a heavy analyis before ledning money to Debt consolidation(packaging a lot of loans into 1) and Medical expenses (unfortunatley, there are factors like whether the indivdual can have income after their procedure or factors like that can influence loan obligations). 
