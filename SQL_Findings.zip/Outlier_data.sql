SELECT 
    CASE 
        WHEN person_age < 20 THEN '0-19'
        WHEN person_age >= 20 AND person_age < 40 THEN '20-39'
        WHEN person_age >= 40 AND person_age < 60 THEN '40-59'
        WHEN person_age >= 60 AND person_age < 80 THEN '60-79'
        ELSE '80+' 
    END AS age_group,
    COUNT(*) AS Outlier_Count,
    SUM(CASE WHEN loan_status = 1 THEN 1 ELSE 0 END) AS Bankrupt_Outliers,
    AVG(person_income) AS Avg_Outlier_Income
FROM 
    SQL_Data
WHERE 
    person_income > 1000000  
GROUP BY 
	age_group
ORDER BY 
    MIN(person_age);
-- There are around 24 out of 45000 people that have  income greater than 1000000.
-- These customer data would be filtered just to ensure he model is more accurate.
-- Further analysis about the age is yet to occur.
