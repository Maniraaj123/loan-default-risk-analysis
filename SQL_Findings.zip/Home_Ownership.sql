SELECT
    person_home_ownership,
    SUM(CASE WHEN loan_status = 1 THEN 1 ELSE 0 END) AS Bankrupt,
    SUM(CASE WHEN loan_status = 0 THEN 1 ELSE 0 END) AS [Still in],
    -- This calculates the decimal, then chops it off into a whole number
    CAST(SUM(CASE WHEN loan_status = 1 THEN 1.0 ELSE 0.0 END) / COUNT(*) * 100 AS Decimal) AS Bankrupt_Pct
FROM
    SQL_Data
GROUP BY
    person_home_ownership;
	
-- Now we can clealy see that a person's living status heavily influence whether someone can repay their loan or not. 
-- Mainly those who live in an untraditional form (like other), or those who are renting a property or more likely to get bankrupt in comparison to others.
-- An additional factor to consider this those who own their property are less likely to get bankrupt. Probably because they would see their property to repay their loan obligations.
-- This is very important factor to consider.  