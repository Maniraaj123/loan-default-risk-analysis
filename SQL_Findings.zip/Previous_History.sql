SELECT
    previous_loan_defaults_on_file,
    SUM(CASE WHEN loan_status = 1 THEN 1 ELSE 0 END) AS Bankrupt,
    SUM(CASE WHEN loan_status = 0 THEN 1 ELSE 0 END) AS [Still in],
    -- This calculates the decimal, then chops it off into a whole number
    CAST(SUM(CASE WHEN loan_status = 1 THEN 1.0 ELSE 0.0 END) / COUNT(*) * 100 AS Decimal) AS Bankrupt_Pct
FROM
    SQL_Data
GROUP BY
    previous_loan_defaults_on_file;
	
-- Clearly those who were bankrupt are more likely to default by around 45% based on this data.