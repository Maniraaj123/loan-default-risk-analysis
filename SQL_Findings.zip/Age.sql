SELECT
    person_gender,
    SUM(CASE WHEN loan_status = 1 THEN 1 ELSE 0 END) AS Bankrupt,
    SUM(CASE WHEN loan_status = 0 THEN 1 ELSE 0 END) AS [Still in],
    -- This calculates the decimal, then chops it off into a whole number
    CAST(SUM(CASE WHEN loan_status = 1 THEN 1.0 ELSE 0.0 END) / COUNT(*) * 100 AS Decimal) AS Bankrupt_Pct
FROM
    SQL_Data
GROUP BY
    person_gender;
-- From our previous conversation, we can see that gender doesn't heavility influence an indidual's ability to repay their payments.
-- So it would be wise to remove this model or we can do some interaction check. 