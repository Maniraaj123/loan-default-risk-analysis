SELECT
    person_education,
    SUM(CASE WHEN loan_status = 1 THEN 1 ELSE 0 END) AS Bankrupt,
    SUM(CASE WHEN loan_status = 0 THEN 1 ELSE 0 END) AS [Still in],
    -- This calculates the decimal, then chops it off into a whole number
    CAST(SUM(CASE WHEN loan_status = 1 THEN 1.0 ELSE 0.0 END) / COUNT(*) * 100 AS Decimal) AS Bankrupt_Pct
FROM
    SQL_Data
GROUP BY
    person_education;
-- Now we can see that a person's education doesn't neccesary affect whteher some one can repay their loan or not. 
-- We can use chi square dist to confirm this but isn't necessary 