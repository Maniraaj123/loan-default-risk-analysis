SELECT 
    CASE 
        WHEN person_age < 10 THEN '0-9'
        WHEN person_age >= 10 AND person_age < 20 THEN '10-19'
        WHEN person_age >= 20 AND person_age < 30 THEN '20-29'
        WHEN person_age >= 30 AND person_age < 40 THEN '30-39'
		WHEN person_age >= 40 AND person_age < 50 THEN '40-49'
		WHEN person_age >= 50 AND person_age < 60 THEN '50-59'
        ELSE '60+' 
    END AS age_group,
    COUNT(*) AS Total_Customers,
    SUM(CASE WHEN loan_status = 1 THEN 1 ELSE 0 END) AS Bankrupt,
    SUM(CASE WHEN loan_status = 0 THEN 1 ELSE 0 END) AS [Still in],
    ROUND(100.0 * SUM(CASE WHEN loan_status = 1 THEN 1 ELSE 0 END) / COUNT(*), 2) AS bankruptcy_rate_pct
FROM 
    SQL_Data
GROUP BY 
	age_group
ORDER BY 
    MIN(person_age);
-- Ok now, based on this we can see that the youngest person allowed to borrow is 20 and there is no age limit as there is someone who is around 140 years old.
-- Finally there is a slight relationship between people generally tend to get bankrupt in the earliers stage although the dataset is pretty skewed as in a lot of young people borrow when at young age.  
 