-- Propotion of bankruptcy
SELECT
	sum(CASE WHEN loan_status == 1 THEN 1 END) AS Bankrupt,
	sum(CASE WHEN loan_status == 0 THEN 1 END) AS [Still in]
	
FROM
	loan_data